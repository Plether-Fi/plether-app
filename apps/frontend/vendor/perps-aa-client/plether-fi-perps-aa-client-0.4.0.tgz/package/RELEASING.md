# Releasing the perps AA client

Core owns the client sources, protection ABI, paymaster contract, tests, and
deployment tooling. npm package versions use their own immutable
`perps-aa-client-vX.Y.Z` tags; they do not move or replace protocol deployment
tags. Publishing a client does not deploy a contract or enable sponsorship.

The current source version is **0.4.0**, a breaking SDK for the new settlement-token
deployment. It uses `settlementToken`, `settlementTokenRuntimeCodeHash`, and
financial fields ending in `Assets`, with no aliases for former token-specific
names. The archived `orderLifecycleV4Abi` is no longer exported or included in
the built package. Historical deployments must use their matching older package.

This implementation authorizes local validation and a local tarball only. Do not
publish the package, deploy contracts, activate sponsorship, or broadcast
transactions. The publication procedures below are for a separately authorized
future release.

## One-time administration

Before the first release, configure the Core `github-packages` environment with
at least one required reviewer. The publish script reads back the environment
and rejects an unprotected environment, including one automatically created by
GitHub. Configure the environment to allow `master`. The workflow also requires
`refs/heads/master` and checks the current remote head before first publication.

After publication, verify that `perps-aa-client` is public in the `Plether-Fi`
organization, linked to `Plether-Fi/plether-core`, and grants
`Plether-Fi/plether-app` Actions read access. First publication can default to
private despite publish access metadata; an administrator must verify/change
visibility. Public visibility does not remove npm authentication requirements.
See [GitHub's npm registry documentation](https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-npm-registry).

## Before merging

```bash
npm ci --prefix packages/perps-aa-client
npm run typecheck --prefix packages/perps-aa-client
npm test --prefix packages/perps-aa-client
npm run build --prefix packages/perps-aa-client
forge test --root packages/perps-aa
node --test scripts/perps-aa-release.test.mjs
```

CI packs from a clean committed checkout, verifies the file allowlist, license,
exports, embedded `gitHead`, and self-contained source maps, then installs the
tarball in a temporary consumer outside Core. The consumer runs the same fixed
compatibility vectors as the source tests, including the changed protection
create, replace, and protected-open encodings and the new latched-limits amendment
action through the native sponsorship/journaling path. The reviewed
`current-assets-v5-schema.json` pins current ABI hashes and six protection action
vectors; the seven other action vectors and sponsorship hashes stay pinned to
their prior values. The fixture guard rejects retired token identifiers in
current ABIs and unreviewed export changes. Renaming intent fields changes the
Book's `INTENT_TYPEHASH` even though request V3 and receipt/configuration V5 domains
remain unchanged.

The historical `baseline.json` and `current-v5-schema.json` fixtures remain
unchanged. The original V4 ABI is preserved under
`test/compatibility/historical/orderLifecycleV4Abi.ts`, outside `src` and the
package file allowlist. Solidity continues to consume `baseline.json` and
independently checks its historical sponsorship hashes. These files are evidence,
not compatibility aliases for the current SDK.

The opt-in Arbitrum Sepolia fork test must also pass before approving the first
release. Run it with an authenticated read-only RPC if the public endpoint is
unavailable; no broadcasts or real funding are involved:

```bash
ARBITRUM_SEPOLIA_RPC_URL=https://sepolia-rollup.arbitrum.io/rpc \
  forge test --root packages/perps-aa --match-contract PletherVerifyingPaymasterForkTest -vv
```

## Local artifact after the final Core commit

Complete the source changes, version/lockfile update, and validation first. Commit
the final Core tree before packaging so the embedded `gitHead` identifies the
exact implementation. The pack command rejects a dirty checkout. Use the existing
pack and independent-consumer smoke workflow with a fresh directory outside Core:

```bash
artifact_dir="$(mktemp -d "${TMPDIR:-/tmp}/perps-aa-0.4.0.XXXXXX")"
node scripts/perps-aa-artifact.mjs pack "$artifact_dir"
node scripts/perps-aa-artifact.mjs smoke "$artifact_dir"
```

Retain the `plether-fi-perps-aa-client-0.4.0.tgz` tarball and `release.json`
together. The manifest records the final commit and SHA-512 integrity. This
workflow creates and verifies a local artifact without publishing or deploying.

## Publish the merged version

Commit the new stable version and lockfile, then merge the reviewed Core PR.
Use the GitHub CLI for dispatch and monitoring, substituting that merged version:

```bash
gh auth status
gh api user --jq .login
gh api repos/Plether-Fi/plether-core/commits/master --jq .sha
gh run list --repo Plether-Fi/plether-core --workflow publish-perps-aa-client.yml --limit 10
gh workflow run publish-perps-aa-client.yml --repo Plether-Fi/plether-core --ref master -f version=X.Y.Z
```

Confirm the run's `headSha`, inspect its build/test results, then approve the
protected `github-packages` job. The read-only build job uploads one tarball and
`release.json`; the protected job downloads that exact artifact and verifies its
SHA-512 integrity. It performs no install, build, lifecycle scripts, or repack.
Only that job has package-write and tag/release-write permissions.

Publishing is followed by registry `gitHead`/integrity readback, an annotated
`perps-aa-client-vX.Y.Z` tag at that commit, and a GitHub Release containing the
integrity and commit. The package release is never marked the repository's latest
protocol release. Use `gh run view` and `gh run watch --exit-status` for completion.

## Recovery

If publication succeeded but readback/tag/release creation failed, rerun only the
failed publish job from that same workflow run (`gh run rerun RUN_ID --failed`).
It reuses the uploaded artifact. An existing version is accepted only when its
`gitHead` and integrity match, and an existing tag must point to the same commit.
Existing release metadata must match exactly. A mismatch requires investigation;
never delete, overwrite, or republish the version. Artifact retention is 30 days;
resolve partial releases within that window.

## Consumer upgrade gate

Only after public visibility and app Actions access are verified should
plether-app replace its vendor dependency with the exact registry version.
Its lockfile must record the returned registry tarball URL and integrity. Verify
a clean `npm ci` using the app workflow's `GITHUB_TOKEN`, then run the frontend,
Storybook, and AA integration checks. Record the Core PR, merged SHA, package tag,
version, and integrity in the app's runbook. An install against a locally built
tarball proves compatibility but does not satisfy the registry-access gate.
